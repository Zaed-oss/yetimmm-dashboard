import { useEffect } from 'react'

// Safe Telegram Mini App integration.
// Works inside Telegram and silently no-ops in a normal browser.
export function useTelegram() {
  useEffect(() => {
    const tg = window.Telegram?.WebApp
    if (!tg) return
    try {
      tg.ready()
      tg.expand()
      tg.setHeaderColor('#0a0d14')
      tg.setBackgroundColor('#0a0d14')
      tg.MainButton.hide()
      tg.BackButton.hide()
    } catch (e) {
      // ignore — running outside Telegram
    }
  }, [])

  return {
    haptic: (style = 'light') => {
      try {
        window.Telegram?.WebApp?.HapticFeedback?.impactOccurred(style)
      } catch (e) { /* noop */ }
    },
    user: window.Telegram?.WebApp?.initDataUnsafe?.user || null,
  }
}
