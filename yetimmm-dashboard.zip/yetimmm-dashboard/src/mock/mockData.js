// ─────────────────────────────────────────────────────────────
// Mock Data layer.
// Everything the dashboard renders comes from these objects.
// Replace these with real API responses later — component code
// does not change.
// ─────────────────────────────────────────────────────────────

export const mockData = {
  bot: {
    status: 'running',        // 'running' | 'stopped'
    mt5Connected: true,
    marketOpen: true,
    lastUpdate: '10:25:32',
  },

  market: {
    symbol: 'XAUUSD',
    price: 4138.25,
    bid: 4138.20,
    ask: 4138.38,
    spread: 0.18,
    changePercent: +0.25,
    status: 'open',           // 'open' | 'closed'
  },

  trading: {
    buyStop: { price: 4138.00, status: 'ready' },   // ready | executed | cancelled
    sellStop: { price: 4137.00, status: 'ready' },
  },

  position: {
    open: true,
    type: 'BUY',              // 'BUY' | 'SELL'
    entry: 4138.00,
    lot: 0.01,
    sl: 4137.00,
    tp: 4158.00,
  },

  risk: {
    initialRisk: 1.00,
    currentRisk: 1.05,
    accumulatedLoss: 1.00,
    nextRisk: 1.05,
    currentLot: 0.01,
    slDistance: 1.00,
    tpDistance: 20.00,
    riskReward: '1:20',
    tradeSequence: 3,
  },

  performance: {
    totalTrades: 27,
    winRate: 63,
    netProfit: 18.40,
    today: 3.20,
  },

  lastTrade: {
    id: 27,
    type: 'BUY',
    entry: 4138.00,
    exit: 4158.00,
    lot: 0.01,
    result: 'TAKE PROFIT',
    pl: 20.00,
  },

  alerts: [
    { id: 1, type: 'success', title: 'Trade Opened', time: '2', unit: 'minutesAgo' },
    { id: 2, type: 'danger',  title: 'Stop Loss Hit', time: '15', unit: 'minutesAgo' },
    { id: 3, type: 'success', title: 'Take Profit', time: '1', unit: 'hoursAgo' },
    { id: 4, type: 'warning', title: 'High Spread', time: '2', unit: 'hoursAgo' },
  ],
}

// Number / currency formatters — keep formatting logic in one place.
export const fmt = {
  price: (v) => v.toFixed(2),
  money: (v, sign = false) =>
    `${sign && v > 0 ? '+' : ''}$${Math.abs(v).toFixed(2)}`,
  signedMoney: (v) => `${v >= 0 ? '+' : '-'}$${Math.abs(v).toFixed(2)}`,
  percent: (v) => `${v >= 0 ? '+' : ''}${v.toFixed(2)}%`,
}
