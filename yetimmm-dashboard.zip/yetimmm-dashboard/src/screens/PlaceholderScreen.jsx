import Card from '../components/Card.jsx'

// Simple placeholder for secondary tabs — keeps navigation fully functional.
export default function PlaceholderScreen({ title, t }) {
  return (
    <div className="screen fade-up">
      <Card title={title}>
        <div className="empty-state">
          <h3 className="empty-state__title">{title}</h3>
          <p className="empty-state__sub">{t.comingSoon}</p>
        </div>
      </Card>
    </div>
  )
}
