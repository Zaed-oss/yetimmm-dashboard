import { useEffect, useMemo, useState } from 'react'
import { getStrings } from './i18n/strings.js'
import { mockData } from './mock/mockData.js'
import { useTelegram } from './hooks/useTelegram.js'

import Header from './components/Header.jsx'
import BotStatusCard from './components/BotStatusCard.jsx'
import MarketCard from './components/MarketCard.jsx'
import TradingSetupCard from './components/TradingSetupCard.jsx'
import OpenPositionCard from './components/OpenPositionCard.jsx'
import RiskCard from './components/RiskCard.jsx'
import PerformanceCard from './components/PerformanceCard.jsx'
import LastTradeCard from './components/LastTradeCard.jsx'
import AlertsCard from './components/AlertsCard.jsx'
import BottomNavigation from './components/BottomNavigation.jsx'
import ConfirmModal from './components/ConfirmModal.jsx'
import PlaceholderScreen from './screens/PlaceholderScreen.jsx'

const NAV_TITLES = {
  trades: 'navTrades',
  orders: 'navOrders',
  statistics: 'navStatistics',
  settings: 'navSettings',
}

export default function App() {
  const [lang] = useState('en') // swap to 'ar' to preview Arabic
  const t = useMemo(() => getStrings(lang), [lang])

  const [bot, setBot] = useState(mockData.bot)
  const [market, setMarket] = useState(mockData.market)
  const [trading] = useState(mockData.trading)
  const [position] = useState(mockData.position)
  const [risk] = useState(mockData.risk)
  const [performance] = useState(mockData.performance)
  const [lastTrade] = useState(mockData.lastTrade)
  const [alerts] = useState(mockData.alerts)

  const [activeTab, setActiveTab] = useState('home')
  const [modalOpen, setModalOpen] = useState(false)

  const { haptic } = useTelegram()

  // Simulated live price feed — replace with WebSocket/API later.
  useEffect(() => {
    const id = setInterval(() => {
      setMarket((m) => {
        const drift = (Math.random() - 0.5) * 0.1
        const price = +(m.price + drift).toFixed(2)
        return {
          ...m,
          price,
          bid: +(price - 0.05).toFixed(2),
          ask: +(price + 0.13).toFixed(2),
          spread: 0.18,
          changePercent: +(m.changePercent + drift / 100).toFixed(2),
        }
      })
      setBot((b) => ({ ...b, lastUpdate: new Date().toLocaleTimeString('en-GB') }))
    }, 3000)
    return () => clearInterval(id)
  }, [])

  const handleStart = () => setBot((b) => ({ ...b, status: 'running' }))
  const handleStopRequest = () => setModalOpen(true)
  const handleConfirmStop = () => {
    haptic('heavy')
    setBot((b) => ({ ...b, status: 'stopped' }))
    setModalOpen(false)
  }

  return (
    <div className="app" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
      <div className="app__container">
        <Header t={t} connected={bot.mt5Connected} onSettings={() => setActiveTab('settings')} />

        <main className="app__main" key={activeTab}>
          {activeTab === 'home' ? (
            <>
              <BotStatusCard
                t={t}
                bot={bot}
                onStart={handleStart}
                onStopRequest={handleStopRequest}
                haptic={haptic}
              />
              <MarketCard t={t} market={market} />
              <TradingSetupCard t={t} trading={trading} />
              <OpenPositionCard t={t} position={position} currentPrice={market.price} />
              <RiskCard t={t} risk={risk} />
              <PerformanceCard t={t} performance={performance} />
              <LastTradeCard t={t} lastTrade={lastTrade} />
              <AlertsCard t={t} alerts={alerts} />
            </>
          ) : (
            <PlaceholderScreen title={t[NAV_TITLES[activeTab]]} t={t} />
          )}
        </main>

        <BottomNavigation t={t} active={activeTab} onChange={setActiveTab} haptic={haptic} />
      </div>

      <ConfirmModal
        t={t}
        open={modalOpen}
        onCancel={() => setModalOpen(false)}
        onConfirm={handleConfirmStop}
      />
    </div>
  )
}
