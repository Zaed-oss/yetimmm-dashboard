import Card from './Card.jsx'
import StatusBadge from './StatusBadge.jsx'
import StatCard from './StatCard.jsx'
import { fmt } from '../mock/mockData.js'

export default function MarketCard({ t, market }) {
  const up = market.changePercent >= 0

  return (
    <Card
      title={t.xauusd}
      delay={60}
      titleExtra={
        <StatusBadge tone={market.status === 'open' ? 'success' : 'danger'} label={market.status === 'open' ? t.open : t.closed} />
      }
    >
      <div className="market-card__price-row">
        <span className={`market-card__price mono ${up ? 'text-up' : 'text-down'}`}>
          {fmt.price(market.price)}
        </span>
        <span className={`market-card__change mono ${up ? 'text-up' : 'text-down'}`}>
          {fmt.percent(market.changePercent)}
        </span>
      </div>

      <div className="grid grid--3">
        <StatCard label={t.bid} value={fmt.price(market.bid)} />
        <StatCard label={t.ask} value={fmt.price(market.ask)} />
        <StatCard label={t.spread} value={fmt.price(market.spread)} />
      </div>
    </Card>
  )
}
