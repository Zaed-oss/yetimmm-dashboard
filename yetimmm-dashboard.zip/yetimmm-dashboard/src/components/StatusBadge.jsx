// Reusable status pill: dot + label, tone-driven colors.
export default function StatusBadge({ tone = 'success', label }) {
  return (
    <span className={`badge badge--${tone}`}>
      <span className="badge__dot" />
      {label}
    </span>
  )
}
