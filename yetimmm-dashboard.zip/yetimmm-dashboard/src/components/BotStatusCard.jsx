import Card from './Card.jsx'
import StatusBadge from './StatusBadge.jsx'
import { IconPlay, IconStop, IconClock } from './icons.jsx'

export default function BotStatusCard({ t, bot, onStopRequest, onStart, haptic }) {
  const running = bot.status === 'running'

  return (
    <Card title={t.botStatus} delay={0} className="bot-card">
      <div className="bot-card__status">
        <StatusBadge tone={running ? 'success' : 'danger'} label={running ? t.running : t.stopped} />
        <span className="bot-card__update mono">
          <IconClock width={13} height={13} />
          {t.lastUpdate} {bot.lastUpdate}
        </span>
      </div>

      <div className="bot-card__meta">
        <div className="bot-card__meta-item">
          <span className="bot-card__meta-label">{t.mt5}</span>
          <StatusBadge
            tone={bot.mt5Connected ? 'success' : 'danger'}
            label={bot.mt5Connected ? t.connected : t.disconnected}
          />
        </div>
        <div className="bot-card__meta-item">
          <span className="bot-card__meta-label">{t.market}</span>
          <StatusBadge
            tone={bot.marketOpen ? 'success' : 'warning'}
            label={bot.marketOpen ? t.open : t.closed}
          />
        </div>
      </div>

      <button
        className={`action-btn ${running ? 'action-btn--danger' : 'action-btn--success'}`}
        onClick={() => {
          haptic('medium')
          running ? onStopRequest() : onStart()
        }}
      >
        {running ? <IconStop width={18} height={18} /> : <IconPlay width={18} height={18} />}
        {running ? t.stopBot : t.startBot}
      </button>
    </Card>
  )
}
