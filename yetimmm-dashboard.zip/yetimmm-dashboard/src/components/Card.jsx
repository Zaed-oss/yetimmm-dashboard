// Generic section card wrapper: title row + animated entrance.
export default function Card({ title, titleExtra, children, className = '', delay = 0 }) {
  return (
    <section className={`card fade-up ${className}`} style={{ animationDelay: `${delay}ms` }}>
      {title && (
        <header className="card__header">
          <h2 className="card__title">{title}</h2>
          {titleExtra}
        </header>
      )}
      {children}
    </section>
  )
}
