import Card from './Card.jsx'
import StatCard from './StatCard.jsx'
import { fmt } from '../mock/mockData.js'

export default function PerformanceCard({ t, performance }) {
  return (
    <Card title={t.performance} delay={300}>
      <div className="grid grid--2">
        <StatCard label={t.totalTrades} value={performance.totalTrades} />
        <StatCard label={t.winRate} value={`${performance.winRate}%`} tone="up" />
        <StatCard label={t.netProfit} value={fmt.signedMoney(performance.netProfit)} tone={performance.netProfit >= 0 ? 'up' : 'down'} />
        <StatCard label={t.today} value={fmt.signedMoney(performance.today)} tone={performance.today >= 0 ? 'up' : 'down'} />
      </div>
    </Card>
  )
}
