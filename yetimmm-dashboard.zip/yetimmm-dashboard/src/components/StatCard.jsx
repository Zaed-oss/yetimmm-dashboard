// Small stat tile used inside grids (Performance, Risk, Market...).
export default function StatCard({ label, value, tone = 'neutral', mono = true }) {
  return (
    <div className={`stat stat--${tone}`}>
      <span className="stat__label">{label}</span>
      <span className={`stat__value${mono ? ' mono' : ''}`}>{value}</span>
    </div>
  )
}
