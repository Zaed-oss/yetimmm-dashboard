import { IconHome, IconTrades, IconOrders, IconStats, IconSettings } from './icons.jsx'

const items = [
  { id: 'home', Icon: IconHome },
  { id: 'trades', Icon: IconTrades },
  { id: 'orders', Icon: IconOrders },
  { id: 'statistics', Icon: IconStats },
  { id: 'settings', Icon: IconSettings },
]

export default function BottomNavigation({ t, active, onChange, haptic }) {
  const labels = {
    home: t.navHome,
    trades: t.navTrades,
    orders: t.navOrders,
    statistics: t.navStatistics,
    settings: t.navSettings,
  }

  return (
    <nav className="bottom-nav">
      {items.map(({ id, Icon }) => (
        <button
          key={id}
          className={`bottom-nav__item${active === id ? ' bottom-nav__item--active' : ''}`}
          onClick={() => {
            haptic('light')
            onChange(id)
          }}
        >
          <Icon width={22} height={22} />
          <span className="bottom-nav__label">{labels[id]}</span>
        </button>
      ))}
    </nav>
  )
}
