import Card from './Card.jsx'
import StatusBadge from './StatusBadge.jsx'
import StatCard from './StatCard.jsx'
import { IconEmpty } from './icons.jsx'
import { fmt } from '../mock/mockData.js'

export default function OpenPositionCard({ t, position, currentPrice }) {
  if (!position.open) {
    return (
      <Card title={t.openPosition} delay={180}>
        <div className="empty-state">
          <IconEmpty width={40} height={40} />
          <h3 className="empty-state__title">{t.noOpenPosition}</h3>
          <p className="empty-state__sub">{t.waitingSignal}</p>
        </div>
      </Card>
    )
  }

  const isBuy = position.type === 'BUY'
  const diff = isBuy ? currentPrice - position.entry : position.entry - currentPrice
  const pl = diff * position.lot * 100 // 1.00 lot = 100 oz on XAUUSD
  const plTone = pl >= 0 ? 'up' : 'down'

  return (
    <Card
      title={t.openPosition}
      delay={180}
      titleExtra={<StatusBadge tone={isBuy ? 'success' : 'danger'} label={position.type} />}
    >
      <div className="grid grid--3">
        <StatCard label={t.entry} value={fmt.price(position.entry)} />
        <StatCard label={t.current} value={fmt.price(currentPrice)} tone={plTone} />
        <StatCard label={t.lot} value={position.lot.toFixed(2)} />
        <StatCard label={t.sl} value={fmt.price(position.sl)} tone="down" />
        <StatCard label={t.tp} value={fmt.price(position.tp)} tone="up" />
        <StatCard label={t.pl} value={fmt.signedMoney(pl)} tone={plTone} />
      </div>
    </Card>
  )
}
