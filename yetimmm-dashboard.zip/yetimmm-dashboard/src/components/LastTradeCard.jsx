import Card from './Card.jsx'
import StatusBadge from './StatusBadge.jsx'
import StatCard from './StatCard.jsx'
import { fmt } from '../mock/mockData.js'

export default function LastTradeCard({ t, lastTrade }) {
  const isBuy = lastTrade.type === 'BUY'
  const isWin = lastTrade.pl >= 0

  return (
    <Card
      title={t.lastTrade}
      delay={360}
      titleExtra={
        <span className="last-trade__head">
          <span className="mono last-trade__id">Trade #{lastTrade.id}</span>
          <StatusBadge tone={isBuy ? 'success' : 'danger'} label={lastTrade.type} />
        </span>
      }
    >
      <div className="grid grid--2">
        <StatCard label={t.entry} value={fmt.price(lastTrade.entry)} />
        <StatCard label={t.exit} value={fmt.price(lastTrade.exit)} />
        <StatCard label={t.lot} value={lastTrade.lot.toFixed(2)} />
        <StatCard label={t.result} value={lastTrade.result} tone={isWin ? 'up' : 'down'} mono={false} />
      </div>
      <div className="last-trade__pl">
        <span className="last-trade__pl-label">{t.pl}</span>
        <span className={`last-trade__pl-value mono ${isWin ? 'text-up' : 'text-down'}`}>
          {fmt.signedMoney(lastTrade.pl)}
        </span>
      </div>
      <button className="ghost-btn">{t.viewDetails}</button>
    </Card>
  )
}
