import Card from './Card.jsx'
import StatusBadge from './StatusBadge.jsx'
import { fmt } from '../mock/mockData.js'

function SetupRow({ label, price, status, t }) {
  const toneMap = { ready: 'success', executed: 'info', cancelled: 'danger' }
  const labelMap = { ready: t.ready, executed: t.executed, cancelled: t.cancelled }
  return (
    <div className="setup-row">
      <div className="setup-row__info">
        <span className="setup-row__label">{label}</span>
        <span className="setup-row__price mono">{fmt.price(price)}</span>
      </div>
      <StatusBadge tone={toneMap[status]} label={labelMap[status]} />
    </div>
  )
}

export default function TradingSetupCard({ t, trading }) {
  return (
    <Card title={t.tradingSetup} delay={120}>
      <div className="setup-list">
        <SetupRow label={t.buyStop} price={trading.buyStop.price} status={trading.buyStop.status} t={t} />
        <SetupRow label={t.sellStop} price={trading.sellStop.price} status={trading.sellStop.status} t={t} />
      </div>
    </Card>
  )
}
