import Card from './Card.jsx'
import StatCard from './StatCard.jsx'
import { IconShield, IconHistory } from './icons.jsx'
import { fmt } from '../mock/mockData.js'

export default function RiskCard({ t, risk }) {
  return (
    <Card title={t.riskManagement} delay={240} titleExtra={<IconShield width={18} height={18} className="card__icon" />}>
      <div className="grid grid--2">
        <StatCard label={t.initialRisk} value={fmt.money(risk.initialRisk)} />
        <StatCard label={t.currentRisk} value={fmt.money(risk.currentRisk)} />
        <StatCard label={t.accumulatedLoss} value={fmt.money(risk.accumulatedLoss)} tone="down" />
        <StatCard label={t.nextRisk} value={fmt.money(risk.nextRisk)} tone="up" />
        <StatCard label={t.currentLot} value={risk.currentLot.toFixed(2)} />
        <StatCard label={t.estimatedSlLoss} value={fmt.money(risk.slDistance)} tone="down" />
        <StatCard label={t.riskReward} value={risk.riskReward} tone="up" />
      </div>

      <div className="sequence">
        <div className="sequence__head">
          <IconHistory width={15} height={15} />
          <span>{t.tradeSequence}</span>
        </div>
        <div className="sequence__chips">
          {Array.from({ length: Math.max(risk.tradeSequence, 1) }, (_, i) => (
            <span key={i} className={`sequence__chip${i === risk.tradeSequence - 1 ? ' sequence__chip--active' : ''}`}>
              #{i + 1}
            </span>
          ))}
        </div>
      </div>
    </Card>
  )
}
