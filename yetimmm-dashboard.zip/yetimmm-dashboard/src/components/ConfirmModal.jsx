import { IconWarn } from './icons.jsx'

export default function ConfirmModal({ t, open, onCancel, onConfirm }) {
  if (!open) return null

  const points = [t.stopModalPoint1, t.stopModalPoint2, t.stopModalPoint3]

  return (
    <div className="modal-overlay" role="dialog" aria-modal="true">
      <div className="modal">
        <div className="modal__icon">
          <IconWarn width={26} height={26} />
        </div>
        <h3 className="modal__title">{t.stopModalTitle}</h3>
        <p className="modal__text">{t.stopModalText}</p>
        <ul className="modal__list">
          {points.map((p) => (
            <li key={p}>{p}</li>
          ))}
        </ul>
        <div className="modal__actions">
          <button className="modal__btn modal__btn--cancel" onClick={onCancel}>
            {t.cancel}
          </button>
          <button className="modal__btn modal__btn--danger" onClick={onConfirm}>
            {t.confirmStop}
          </button>
        </div>
      </div>
    </div>
  )
}
