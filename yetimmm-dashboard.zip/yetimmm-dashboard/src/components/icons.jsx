// Centralized inline SVG icons — no emoji dependency, crisp on any screen.
const base = { fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round' }

export const IconHome = (p) => (
  <svg viewBox="0 0 24 24" {...base} {...p}><path d="M3 10.5 12 3l9 7.5" /><path d="M5 9.5V21h14V9.5" /><path d="M9 21v-6h6v6" /></svg>
)
export const IconTrades = (p) => (
  <svg viewBox="0 0 24 24" {...base} {...p}><path d="M7 17 17 7" /><path d="M8 7h9v9" /></svg>
)
export const IconOrders = (p) => (
  <svg viewBox="0 0 24 24" {...base} {...p}><rect x="5" y="4" width="14" height="17" rx="2" /><path d="M9 4a2 2 0 0 1 6 0" /><path d="M9 10h6M9 14h6M9 18h4" /></svg>
)
export const IconStats = (p) => (
  <svg viewBox="0 0 24 24" {...base} {...p}><path d="M4 20V10M10 20V4M16 20v-7M22 20H2" /></svg>
)
export const IconSettings = (p) => (
  <svg viewBox="0 0 24 24" {...base} {...p}><circle cx="12" cy="12" r="3.2" /><path d="M19 12a7 7 0 0 0-.14-1.4l2-1.55-2-3.46-2.35.95a7 7 0 0 0-2.42-1.4L13.7 2.6h-3.4l-.39 2.54a7 7 0 0 0-2.42 1.4l-2.35-.95-2 3.46 2 1.55A7 7 0 0 0 5 12c0 .48.05.94.14 1.4l-2 1.55 2 3.46 2.35-.95c.71.62 1.54 1.1 2.42 1.4l.39 2.54h3.4l.39-2.54a7 7 0 0 0 2.42-1.4l2.35.95 2-3.46-2-1.55c.09-.46.14-.92.14-1.4Z" /></svg>
)
export const IconStop = (p) => (
  <svg viewBox="0 0 24 24" {...base} {...p}><rect x="6" y="6" width="12" height="12" rx="2" /></svg>
)
export const IconPlay = (p) => (
  <svg viewBox="0 0 24 24" {...base} {...p}><path d="M7 4.5v15l12-7.5-12-7.5Z" /></svg>
)
export const IconClock = (p) => (
  <svg viewBox="0 0 24 24" {...base} {...p}><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3.5 2" /></svg>
)
export const IconShield = (p) => (
  <svg viewBox="0 0 24 24" {...base} {...p}><path d="M12 2 4 6v6c0 5 3.4 8.4 8 10 4.6-1.6 8-5 8-10V6l-8-4Z" /></svg>
)
export const IconHistory = (p) => (
  <svg viewBox="0 0 24 24" {...base} {...p}><path d="M3 12a9 9 0 1 0 3-6.7" /><path d="M3 4v5h5" /><path d="M12 7v5l3.5 2" /></svg>
)
export const IconBell = (p) => (
  <svg viewBox="0 0 24 24" {...base} {...p}><path d="M18 8a6 6 0 1 0-12 0c0 7-3 8-3 8h18s-3-1-3-8" /><path d="M10.3 21a2 2 0 0 0 3.4 0" /></svg>
)
export const IconEmpty = (p) => (
  <svg viewBox="0 0 24 24" {...base} {...p}><circle cx="12" cy="12" r="9" /><path d="M8 12h8" /></svg>
)
export const IconCheck = (p) => (
  <svg viewBox="0 0 24 24" {...base} {...p}><path d="m4.5 12.5 5 5 10-11" /></svg>
)
export const IconWarn = (p) => (
  <svg viewBox="0 0 24 24" {...base} {...p}><path d="M12 3 2 20h20L12 3Z" /><path d="M12 10v4M12 17.5v.01" /></svg>
)
