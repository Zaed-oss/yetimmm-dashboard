import StatusBadge from './StatusBadge.jsx'
import { IconSettings } from './icons.jsx'

export default function Header({ t, connected, onSettings }) {
  return (
    <header className="header">
      <div className="header__brand">
        <div className="header__logo">Y</div>
        <div className="header__text">
          <h1 className="header__name">{t.appName}</h1>
          <p className="header__sub">{t.appSubtitle}</p>
        </div>
      </div>
      <div className="header__actions">
        <StatusBadge
          tone={connected ? 'success' : 'danger'}
          label={connected ? t.connected : t.disconnected}
        />
        <button className="icon-btn" onClick={onSettings} aria-label={t.settings}>
          <IconSettings width={20} height={20} />
        </button>
      </div>
    </header>
  )
}
