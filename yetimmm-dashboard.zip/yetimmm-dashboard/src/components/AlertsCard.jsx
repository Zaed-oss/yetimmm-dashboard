import Card from './Card.jsx'
import { IconBell, IconCheck, IconWarn } from './icons.jsx'

const toneIcon = {
  success: <IconCheck width={14} height={14} />,
  danger: <IconWarn width={14} height={14} />,
  warning: <IconWarn width={14} height={14} />,
  info: <IconBell width={14} height={14} />,
}

export default function AlertsCard({ t, alerts }) {
  return (
    <Card title={t.recentAlerts} delay={420} titleExtra={<IconBell width={18} height={18} className="card__icon" />}>
      <ul className="alerts">
        {alerts.map((a) => (
          <li key={a.id} className="alerts__item">
            <span className={`alerts__icon alerts__icon--${a.type}`}>{toneIcon[a.type]}</span>
            <span className="alerts__title">{a.title}</span>
            <span className="alerts__time">
              {a.time} {t[a.unit]}
            </span>
          </li>
        ))}
      </ul>
      <button className="ghost-btn">{t.viewAll}</button>
    </Card>
  )
}
