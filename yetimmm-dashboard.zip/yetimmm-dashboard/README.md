# Yetimmm — XAUUSD Dashboard (Telegram Mini App)

React + JavaScript + Vite implementation of the Yetimmm home dashboard.

## Run

```bash
npm install
npm run dev
```

Open http://localhost:5173 (or serve over HTTPS to test inside Telegram).

## Structure

```
src/
  i18n/strings.js        # All UI text (EN/AR ready — switch lang in App.jsx)
  mock/mockData.js       # Mock data layer — swap with real API responses later
  hooks/useTelegram.js   # Telegram WebApp API integration (safe outside Telegram)
  components/            # One component per card (Header, MarketCard, ...)
  screens/               # Secondary tabs (Trades / Orders / Statistics / Settings)
  App.jsx                # State, live price simulation, tab navigation
  index.css              # Design system (dark, premium, mobile-first)
```

## Notes

- Start/Stop button changes bot state; Stop opens a confirmation modal.
- Prices tick every 3s (mock) and P/L of the open position updates live.
- Bottom navigation switches tabs with smooth transitions.
- All strings live in `src/i18n/strings.js` — set `lang` to `'ar'` in `App.jsx` for Arabic.
